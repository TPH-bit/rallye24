
# Team — Rallye24

Scripts:
- `npm run dev` — démarre en local
- `npm run build` — build production
- `npm run preview` — sert le build

Variables requises:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
